# Load modules
import numpy as np

from QMSolver import QMSolver
from helper_functions import *

# Solving the SHO
# Declare Solver Parameters
dt = 0.1
dx = 0.1
t_steps    = 500
resolution = 100
# Declare Gaussian Wave Packet Parameters
sigma = 1.0  # Ground state width
x0 = 0.0      # Initial center position (equilibrium)
k0 = 0.0      # Initial wave number (ground state)
sim = QMSolver(dt=dt, dx=dx, n=resolution, steps=t_steps)
sim.create_grid(-5,5)
sim.gaussian_wave_packet(x0, sigma, k0)
sim.sho_potential()
sim.create_hamiltonian()
sim_solution = sim.solve()

# Check for Probability Conservation
for i in range(len(sim_solution) - 1):
    if i % 100 == 0:
        print(check_norm(sim_solution[i], i, dx))

# Animation
# time_series_data = generate_time_series_psi_real(sim, t_steps)
# animate_psi_squared_series(time_series_data, t_steps, filename='Simple Harmonic Potential.mp4')
